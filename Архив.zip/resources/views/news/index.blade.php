@extends('layouts.app')

@section('title')
  @parent Новости
@endsection

@section('menu')
  @include('menu')
@endsection

@section('content')
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">{{ __('Новости') }}</div>
          <ul class="list-group list-group-flush">
            @forelse ($news as $item)
              <li class="list-group-item">
                <a href="{{ route('news.one', $item->id) }}">{{ $item->title }}</a><br>
              </li>
            @empty
              Нет новостей
            @endforelse
          </ul>
        </div>
        <div class="d-flex p-2 justify-content-center">
          {{ $news->links() }}
        </div>
      </div>
    </div>
  </div>

@endsection
