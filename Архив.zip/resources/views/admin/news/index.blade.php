@extends('layouts.app')

@section('title', 'Admin')

@section('menu')
  @include('admin/menu')
@endsection

@section('content')
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header d-flex justify-content-between align-items-center">Редактирование новостей
            <a href="{{ route('admin.news.create') }}" class="btn btn-success ">Добавить</a>
          </div>
          <ul class="list-group list-group-flush">
            @forelse ($news as $item)
              <li class="list-group-item">
                <a href="{{ route('admin.news.edit', $item) }}">{{ $item->title }}</a>
                <form action="{{ route('admin.news.destroy', $item) }}" enctype="multipart/form-data" method="post">
                  @method('DELETE')
                  @csrf
                  <a href="{{ route('admin.news.edit', $item) }}" class="btn btn-success">Редактировать</a>
                  <input type="submit" class="btn btn-danger" value="Удалить">
                </form>
              </li>
            @empty
              Нет новостей
            @endforelse

          </ul>

        </div>
        <div class="d-flex p-2 justify-content-center">
          {{ $news->links() }}
        </div>
      </div>
    </div>
  </div>
  </div>
@endsection




