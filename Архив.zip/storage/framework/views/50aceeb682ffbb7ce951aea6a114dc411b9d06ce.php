<?php $__env->startSection('title'); ?>
  ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## Новости
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
  <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header"><?php echo e(__('Новости')); ?></div>
          <ul class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="list-group-item">
                <a href="<?php echo e(route('news.one', $item->id)); ?>"><?php echo e($item->title); ?></a><br>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              Нет новостей
            <?php endif; ?>
          </ul>
        </div>
        <div class="d-flex p-2 justify-content-center">
          <?php echo e($news->links()); ?>

        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel.local/resources/views/news/index.blade.php ENDPATH**/ ?>