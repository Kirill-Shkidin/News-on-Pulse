
<li class="nav-item <?php echo e(request()->routeIs('admin.news.index')?'active':''); ?>">
  <a class="nav-link" href="<?php echo e(route('admin.news.index')); ?>">Новости</a>
</li>

<li class="nav-item <?php echo e(request()->routeIs('admin.parser')?'active':''); ?>">
  <a class="nav-link" href="<?php echo e(route('admin.parser')); ?>">Парсить новости</a>
</li>

<li class="nav-item <?php echo e(request()->routeIs('admin.users.index')?'active':''); ?>">
  <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>">Пользователи</a>
</li>


<?php /**PATH /home/vagrant/code/laravel.local/resources/views/admin/menu.blade.php ENDPATH**/ ?>