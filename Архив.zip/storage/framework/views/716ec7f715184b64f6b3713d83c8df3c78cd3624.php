<?php $__env->startSection('title', 'Добавление новости'); ?>


<?php $__env->startSection('menu'); ?>
  <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header"><?php echo e(__('Добавление новости')); ?></div>
          <form action="<?php if($news->id): ?><?php echo e(route('admin.news.update', $news)); ?>

          <?php else: ?><?php echo e(route('admin.news.store', $news)); ?><?php endif; ?>"
                method="post">
            <?php echo csrf_field(); ?>
            <?php if($news->id): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="form-group row mt-4">
              <label for="newsTitle"
                     class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заголовок новости')); ?></label>

              <div class="col-md-6">
                <input id="newsTitle" type="text" class="form-control" name="title"
                       value="<?php echo e(old('title') ?? $news->title); ?>">

                <?php if($errors->has('title')): ?>
                  <div class="alert alert-danger mt-1" role="alert">
                    <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($error); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group row">
              <label for="newsCategory"
                     class="col-md-4 col-form-label text-md-right"><?php echo e(__('Категория новости')); ?></label>
              <div class="col-md-6">
                <select name="category" id="newsCategory" class="form-control">
                  <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option <?php if($item->id == old('category')): ?> selected
                            <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                    <?php if($errors->has('category_id')): ?>
                      <div class="alert alert-danger" role="alert">
                        <?php $__currentLoopData = $errors->get('category_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="null" selected>Нет категорий</option>
                  <?php endif; ?>
                </select>
              </div>
            </div>

            <div class="form-group row">
              <label for="newsText"
                     class="col-md-4 col-form-label text-md-right"><?php echo e(__('Текст новости')); ?></label>
              <div class="col-md-6">
                <textarea name="text" id="newsText" cols="30" rows="10"
                          class="form-control"><?php echo e(old('text') ?? $news->text); ?></textarea>
                <?php if($errors->has('text')): ?>
                  <div class="alert alert-danger mt-1" role="alert">
                    <?php $__currentLoopData = $errors->get('text'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($error); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group row mb-4">
              <div class="col-md-8 offset-md-4">
                <button type="submit" class="btn btn-primary">
                  <?php if($news->id): ?>
                    Сохранить
                  <?php else: ?>
                    Добавить новость
                  <?php endif; ?>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel.local/resources/views/admin/news/create.blade.php ENDPATH**/ ?>