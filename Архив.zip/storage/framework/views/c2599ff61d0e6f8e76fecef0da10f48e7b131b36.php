<li class="nav-item <?php echo e(request()->routeIs('about')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('about')); ?>">О нас</a>
</li>
<li class="nav-item <?php echo e(request()->routeIs('news.index')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('news.index')); ?>">Новости</a>
</li>

<?php if(Auth::user()->status ?? false): ?>
<li class="nav-item <?php echo e(request()->routeIs('admin.news.index')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.news.index')); ?>">Админ</a>
</li>
<?php endif; ?>
<li class="nav-item <?php echo e(request()->routeIs('news.categories.index')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('news.categories.index')); ?>">Категории</a>
</li>
<?php /**PATH /home/vagrant/code/laravel.local/resources/views/menu.blade.php ENDPATH**/ ?>