<?php

namespace App\Http\Controllers\Admin;

use App\News;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Orchestra\Parser\Xml\Facade as XmlParser;

class ParserController extends Controller
{
    public function index() {
      $xml = XmlParser::load('https://news.yandex.ru/business.rss');
//      dump($xml);
      $data = $xml->parse([
        'title' => ['uses' => 'channel.title'],
        'news' => ['uses' => 'channel.item[title,link,guid,description,pubDate]'],
      ]);


//      dump($data);
//      dump(collect(json_decode(json_encode($data['news']))));
      $news = collect(json_decode(json_encode($data['news'])));
//      dump($news);

      return view('admin.news.parse', ['news' => $news]);
    }
}
