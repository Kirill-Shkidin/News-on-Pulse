@extends('layouts.app')

@section('title')
    @parentГлавная
@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
    <div class="card p-3">
        <h1>Привет!</h1>
    </div>

@endsection
