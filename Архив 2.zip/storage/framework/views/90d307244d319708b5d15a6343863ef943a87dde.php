<?php $__env->startSection('title', 'Категории новостей'); ?>

<?php $__env->startSection('menu'); ?>
  <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Категории новостей</div>

          <?php if($data): ?>
            <ul class="list-group list-group-flush">
              <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item">
                  <a href="<?php echo e(route('news.categories.one', $item->slug)); ?>"><?php echo e($item->title); ?></a><br>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Нет категорий
              <?php endif; ?>
            </ul>
          <?php else: ?>
            <h1>Извините</h1>
            <p>Такой категории нет;(</p>
          <?php endif; ?>
        </div>
        <div class="d-flex p-2 justify-content-center">
          <?php echo e($data->links()); ?>

        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel.local/resources/views/news/categories/index.blade.php ENDPATH**/ ?>