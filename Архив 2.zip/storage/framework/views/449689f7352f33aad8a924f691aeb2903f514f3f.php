<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('menu'); ?>
  <?php echo $__env->make('admin/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header d-flex justify-content-between align-items-center">Редактирование новостей
            <a href="<?php echo e(route('admin.news.create')); ?>" class="btn btn-success ">Добавить</a>
          </div>
          <ul class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="list-group-item">
                <a href="<?php echo e(route('admin.news.edit', $item)); ?>"><?php echo e($item->title); ?></a>
                <form action="<?php echo e(route('admin.news.destroy', $item)); ?>" enctype="multipart/form-data" method="post">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                  <a href="<?php echo e(route('admin.news.edit', $item)); ?>" class="btn btn-success">Редактировать</a>
                  <input type="submit" class="btn btn-danger" value="Удалить">
                </form>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              Нет новостей
            <?php endif; ?>

          </ul>

        </div>
        <div class="d-flex p-2 justify-content-center">
          <?php echo e($news->links()); ?>

        </div>
      </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel.local/resources/views/admin/news/index.blade.php ENDPATH**/ ?>